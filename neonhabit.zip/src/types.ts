export interface Habit {
  id: string;
  name: string;
  icon: string;
  color: string;
  progress: number; // 0 to 1
  streak: number;
  frequency: 'daily' | 'weekly';
  reminderTime?: string;
  category: string;
  createdAt: number;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  birthYear?: number;
  stats: {
    totalCompleted: number;
    currentStreak: number;
    completionRate: number;
  };
}
